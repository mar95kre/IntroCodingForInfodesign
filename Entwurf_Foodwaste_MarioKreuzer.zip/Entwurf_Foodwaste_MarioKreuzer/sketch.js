function preload() {

  data = loadTable('FoodWaste_ConfidenceAB.csv', 'ssv', 'header');
  breadFull = loadImage('Bread/01.png');
  breadThreequarter = loadImage('Bread/02.png');
  breadHalf = loadImage('Bread/03.png');
  breadQuarter = loadImage('Bread/04.png');

}



function setup() {
  createCanvas(5000, 5000);
  background("white")
  console.log("Rowcount= " + data.getRowCount());
  console.log(data.columns);

  //Titel
  textSize (100);
  text ('Daily Global Foodwaste', 15, 100);
  
  textSize (40);
  text ('This graphics shows the daily foodwaste in selected Countries around the world. The Bread (1 Loaf = 500g) visualizes the weight of Food wasted by one Person a day. The selection of countries is based on the hight to medium confidence of given data. Other countries not listed, lack in data.  ', 20, 180);

 

  for (var i = 0; i < data.getRowCount(); i++) {
    
    //Textspalte
    noStroke();
    fill("black");
    textSize (40);
    let columnName = data.getString(i, "Country");
    text(columnName, 20, 260 + i * 80);
    

    //Wertespalte
    let columnValue = data.getString(i, " Household estimate (Brote/capita/Woche) Brot=500g");
    text(columnValue, 600, 260 + i * 80);

    //Brotspalte
    image(breadFull, 800, 210, 117, 70)
    image(breadQuarter, 950, 210, 117, 70)
    
    //columnBread = data.getNum(i, " Household estimate (Brote/capita/Woche) Brot=500g");
    //let ColumnBread = image(columnBread; 800+i*150; 210+i*80; 117, 70)

    //console.log(columnBread)

  }

}

function draw() {
  strokeWeight(15);


}